/* =============================================
   MOTHER'S DAY EVENT CHOOSER — APP LOGIC
   ============================================= */

// ── DATA ──────────────────────────────────────

const CENTERS = [
  "Mills Drive",
  "North Miami Beach",
  "Quail Roost",
  "North Bay Village",
  "North Homestead",
  "Plaza Linda",
  "Hialeah",
  "West North Miami",
  "Little Havana",
  "West Kendall",
  "Westland",
  "Liberty City",
  "East Westchester",
  "Westchester"
];

const EVENTS = {
  "Violinist":  { emoji: "🎻", maxPerDate: 1,  color: "violinist" },
  "Mariachi":   { emoji: "🎺", maxPerDate: 2,  color: "mariachi"  },
  "Hora Loca":  { emoji: "🎉", maxPerDate: 2,  color: "horaloca"  }
};

// Generate valid weekdays May 1–29, 2026, excluding specific dates
const EXCLUDED = new Set(["2026-05-02","2026-05-03","2026-05-09","2026-05-10","2026-05-16","2026-05-17","2026-05-23","2026-05-24"]);

function buildDates() {
  const dates = [];
  for (let d = 1; d <= 29; d++) {
    const month = "05";
    const day   = String(d).padStart(2, "0");
    const iso   = `2026-${month}-${day}`;
    const jsDate = new Date(`${iso}T12:00:00`);
    const dow  = jsDate.getDay(); // 0=Sun,6=Sat
    if (dow === 0 || dow === 6) continue;  // skip weekends
    if (EXCLUDED.has(iso)) continue;        // skip excluded
    dates.push({ iso, label: jsDate.toLocaleDateString("en-US", { weekday:"short", month:"short", day:"numeric" }) });
  }
  return dates;
}

const DATES = buildDates();

// ── STATE ─────────────────────────────────────
// selections[centerIndex] = { event: string|null, date: string|null }
let selections = CENTERS.map(() => ({ event: null, date: null }));

// ── AVAILABILITY TRACKING ─────────────────────
function getBookingCounts() {
  // Returns { [eventName]: { [dateIso]: count } }
  const counts = {};
  for (const ev of Object.keys(EVENTS)) {
    counts[ev] = {};
    for (const d of DATES) counts[ev][d.iso] = 0;
  }
  selections.forEach(sel => {
    if (sel.event && sel.date) {
      if (counts[sel.event]) counts[sel.event][sel.date]++;
    }
  });
  return counts;
}

function isDateAvailable(eventName, dateIso, excludeCenter) {
  if (!EVENTS[eventName]) return false;
  const max = EVENTS[eventName].maxPerDate;
  let count = 0;
  selections.forEach((sel, i) => {
    if (i === excludeCenter) return;
    if (sel.event === eventName && sel.date === dateIso) count++;
  });
  return count < max;
}

// ── TABLE BUILD ───────────────────────────────
function buildTable() {
  const tbody = document.getElementById("tableBody");
  tbody.innerHTML = "";

  CENTERS.forEach((name, idx) => {
    const row = document.createElement("tr");
    row.id = `row-${idx}`;

    // 1. Center name
    const tdName = document.createElement("td");
    tdName.innerHTML = `<span class="center-name">${name}</span>`;
    row.appendChild(tdName);

    // 2. Event select
    const tdEvent = document.createElement("td");
    const evSelect = document.createElement("select");
    evSelect.className = "event-select";
    evSelect.id = `event-${idx}`;
    evSelect.innerHTML = `<option value="">— Select Event —</option>` +
      Object.keys(EVENTS).map(ev =>
        `<option value="${ev}" ${selections[idx].event === ev ? "selected" : ""}>${EVENTS[ev].emoji} ${ev}</option>`
      ).join("");
    evSelect.addEventListener("change", () => onEventChange(idx));
    tdEvent.appendChild(evSelect);
    row.appendChild(tdEvent);

    // 3. Date select
    const tdDate = document.createElement("td");
    const dtSelect = document.createElement("select");
    dtSelect.className = "date-select";
    dtSelect.id = `date-${idx}`;
    dtSelect.disabled = !selections[idx].event;
    buildDateOptions(dtSelect, idx);
    dtSelect.addEventListener("change", () => onDateChange(idx));
    tdDate.appendChild(dtSelect);
    row.appendChild(tdDate);

    // 4. Status
    const tdStatus = document.createElement("td");
    tdStatus.id = `status-${idx}`;
    tdStatus.appendChild(makeStatusBadge(idx));
    row.appendChild(tdStatus);

    tbody.appendChild(row);
  });

  // Set event-select color attribute after build
  CENTERS.forEach((_, idx) => refreshEventSelectStyle(idx));
}

function buildDateOptions(dtSelect, idx) {
  const currentEvent = selections[idx].event;
  const currentDate  = selections[idx].date;

  dtSelect.innerHTML = `<option value="">— Select Date —</option>`;
  if (!currentEvent) return;

  DATES.forEach(d => {
    const available = isDateAvailable(currentEvent, d.iso, idx);
    const opt = document.createElement("option");
    opt.value = d.iso;
    opt.textContent = d.label;
    opt.selected = (d.iso === currentDate);
    // Disable if not available AND not currently selected
    opt.disabled = !available && d.iso !== currentDate;
    if (!available && d.iso !== currentDate) {
      opt.textContent += " (full)";
    }
    dtSelect.appendChild(opt);
  });
}

function refreshEventSelectStyle(idx) {
  const evSel = document.getElementById(`event-${idx}`);
  if (!evSel) return;
  const ev = selections[idx].event;
  evSel.removeAttribute("data-event");
  if (ev) evSel.setAttribute("data-event", ev);
}

function makeStatusBadge(idx) {
  const sel = selections[idx];
  const span = document.createElement("span");
  span.className = "status-badge";
  if (sel.event && sel.date) {
    span.classList.add("status-confirmed");
    span.textContent = "✓ Confirmed";
  } else if (sel.event || sel.date) {
    span.classList.add("status-pending");
    span.textContent = "⏳ Pending";
  } else {
    span.classList.add("status-incomplete");
    span.textContent = "Not selected";
  }
  return span;
}

function refreshStatus(idx) {
  const cell = document.getElementById(`status-${idx}`);
  if (!cell) return;
  cell.innerHTML = "";
  cell.appendChild(makeStatusBadge(idx));
}

// ── EVENT HANDLERS ────────────────────────────
function onEventChange(idx) {
  const evSel = document.getElementById(`event-${idx}`);
  const newEvent = evSel.value || null;

  // If event changed, clear date
  if (newEvent !== selections[idx].event) {
    selections[idx].event = newEvent;
    selections[idx].date  = null;
  }

  refreshEventSelectStyle(idx);
  const dtSel = document.getElementById(`date-${idx}`);
  dtSel.disabled = !newEvent;
  buildDateOptions(dtSel, idx);
  refreshStatus(idx);
  refreshAllDateDropdowns(idx);
}

function onDateChange(idx) {
  const dtSel = document.getElementById(`date-${idx}`);
  selections[idx].date = dtSel.value || null;
  refreshStatus(idx);
  refreshAllDateDropdowns(idx);
}

// After any change, refresh date dropdowns for other rows (availability may change)
function refreshAllDateDropdowns(changedIdx) {
  CENTERS.forEach((_, idx) => {
    if (idx === changedIdx) return;
    const dtSel = document.getElementById(`date-${idx}`);
    if (!dtSel || !selections[idx].event) return;
    const prev = selections[idx].date;
    buildDateOptions(dtSel, idx);
    // Restore if still valid
    if (prev) {
      const stillValid = isDateAvailable(selections[idx].event, prev, idx);
      if (stillValid) {
        dtSel.value = prev;
      } else {
        // Date became unavailable — clear it
        selections[idx].date = null;
        dtSel.value = "";
        refreshStatus(idx);
      }
    }
  });
}

// ── SUMMARY SLIDE ─────────────────────────────
function buildSummary() {
  const tbody = document.getElementById("summaryBody");
  tbody.innerHTML = "";

  let confirmed = 0, violinistCount = 0, mariachiCount = 0, horalocaCount = 0;

  // Sort by date for cleaner display
  const sorted = CENTERS.map((name, i) => ({ name, sel: selections[i] }))
    .sort((a, b) => {
      if (!a.sel.date) return 1;
      if (!b.sel.date) return -1;
      return a.sel.date.localeCompare(b.sel.date);
    });

  sorted.forEach(({ name, sel }) => {
    const tr = document.createElement("tr");

    // Center
    const tdC = document.createElement("td");
    tdC.className = "center-col";
    tdC.textContent = name;
    tr.appendChild(tdC);

    // Event pill
    const tdE = document.createElement("td");
    if (sel.event) {
      const pill = document.createElement("span");
      pill.className = `event-pill pill-${EVENTS[sel.event].color}`;
      pill.textContent = `${EVENTS[sel.event].emoji} ${sel.event}`;
      tdE.appendChild(pill);
      if (sel.event === "Violinist") violinistCount++;
      else if (sel.event === "Mariachi") mariachiCount++;
      else if (sel.event === "Hora Loca") horalocaCount++;
    } else {
      const pill = document.createElement("span");
      pill.className = "event-pill pill-none";
      pill.textContent = "Not selected";
      tdE.appendChild(pill);
    }
    tr.appendChild(tdE);

    // Date
    const tdD = document.createElement("td");
    if (sel.date) {
      const d = DATES.find(x => x.iso === sel.date);
      tdD.textContent = d ? d.label : sel.date;
      if (sel.event && sel.date) confirmed++;
    } else {
      tdD.style.color = "var(--text-faint)";
      tdD.textContent = "—";
    }
    tr.appendChild(tdD);

    tbody.appendChild(tr);
  });

  // Stats
  const statsDiv = document.getElementById("summaryStats");
  statsDiv.innerHTML = `
    <div class="stat-card">
      <div class="stat-value">${confirmed}</div>
      <div class="stat-label">Confirmed</div>
    </div>
    <div class="stat-card">
      <div class="stat-value">${CENTERS.length - confirmed}</div>
      <div class="stat-label">Pending</div>
    </div>
    <div class="stat-card stat-violinist">
      <div class="stat-value">${violinistCount}</div>
      <div class="stat-label">🎻 Violinist</div>
    </div>
    <div class="stat-card stat-mariachi">
      <div class="stat-value">${mariachiCount}</div>
      <div class="stat-label">🎺 Mariachi</div>
    </div>
    <div class="stat-card stat-horaloca">
      <div class="stat-value">${horalocaCount}</div>
      <div class="stat-label">🎉 Hora Loca</div>
    </div>
  `;
}

// ── NAVIGATION ────────────────────────────────
const slideOrder = ["slide-title", "slide-rules", "slide-chooser", "slide-summary"];

function goToSlide(id) {
  if (id === "slide-summary") buildSummary();

  document.querySelectorAll(".slide").forEach(s => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");

  // Update dots
  const idx = slideOrder.indexOf(id);
  document.querySelectorAll(".dot").forEach((d, i) => {
    d.classList.toggle("active", i === idx);
  });

  // Scroll to top of slide
  document.getElementById(id).scrollTo(0, 0);
}

// ── UTILITIES ─────────────────────────────────
function printSummary() { window.print(); }

function resetAll() {
  if (!confirm("Reset all selections? This cannot be undone.")) return;
  selections = CENTERS.map(() => ({ event: null, date: null }));
  buildTable();
  buildSummary();
  goToSlide("slide-chooser");
}

// ── INIT ──────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  buildTable();
});
